import React from 'react';
import { StyleSheet,  View} from 'react-native';

const CustomeText = (props) => {
return(
    <View style={styles.box}>
    {props.children}
    </View >
    );
}

const styles = StyleSheet.create({
    box:{
        fontFamily:"Roboto",
        fontSize:30
    }
});

export default CustomeText;