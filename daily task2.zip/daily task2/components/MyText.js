// import React from "react";
// import { StyleSheet, Text, View, Platform, StatusBar } from "react-native";

// export default function MyText(props) {
//   const { name, phoneNumber } = props;
//   return (
//     <View style={styles.container}>
//       <Text style={styles.text}>
//         {name} and {phoneNumber}{" "}
//       </Text>
//       {props.children}
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "yellow",
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   text: {
//     color: "green",
//     textAlign: "center",
//     fontWeight: "bold",
//     fontSize: 20,
//   },
// });


import React from 'react';
import {View} from 'react-native';
import styles  from '../styles/styles';

const CustomText = (props) => {
return(
    <View style={styles.box}>
      {props.children}
    </View >
    

    

    
);
}

// const styles = StyleSheet.create({
 
// });

export default CustomText;
