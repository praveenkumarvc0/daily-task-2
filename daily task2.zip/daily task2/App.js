import React from "react";
import CustomText from './components/MyText';
import {Alert,Button,Image,Platform,StatusBar,SafeAreaView,StyleSheet,Text,TouchableOpacity,
  TouchableWithoutFeedback,View,} from "react-native";
import {useDimensions,useDeviceOrientation,} from "@react-native-community/hooks";
// import Flex from "./Exercises/Flex";
// import MyText from "./components/MyText";
import { MaterialCommunityIcons } from "@expo/vector-icons";

{/*export default function App() {
  return (
    <MyText name="Praveeenkumar V" phoneNumber="7397006165">
      <View style={styles.container1}>
         <MaterialCommunityIcons name="car" color="blue" size={100} />
      </View>
    </MyText>
  );
}

const styles = StyleSheet.create({
  container1: {
    backgroundColor: "pink",
    height: "30%",
    width: "50%",
    alignItems: "center",
    justifyContent: "center",
    marginTop:
      Platform.OS === "android"
        ? StatusBar.currentHeight
        : StatusBar.currentHeight + 10,
  },
});*/}


export default function App() {
  return (
    <View style={styles.container}>
      <CustomText>Hello World</CustomText>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'red',
    alignItems: 'center',
    justifyContent: 'center',
    
  },
});
