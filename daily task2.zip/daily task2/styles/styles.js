import { StyleSheet } from 'react-native';
export default StyleSheet.create({
    
box: {
    color:'blue',
    backgroundColor:"white",
    borderRadius:10,
    fontSize:40,
    justifyContent:'center',
    alignItems:'center',
    
}
});